<?php require_once "./header.php" ?>
<style>
    .text-box {
        width: 90%;
        color: #fff;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
    }

    .text-box h1 {
        font-size: 62px;
    }

    .text-box p {
        margin: 10px 0 40px;
        font-size: 14px;
        color: #fff;
    }

    .btn-link {
        display: inline-block;
        text-decoration: none;
        color: #fff;
        border: 1px solid #fff;
        padding: 12px 34px;
        font-size: 13px;
        background: transparent;
        position: relative;
        cursor: pointer;
    }

    .btn-link:hover {
        border: 1px solid #2a9191;
        background: #2a9191;
        color: #fff;
        transition: 1s;

    }
</style>
<main class="text-box">

    <h1>India's #1 Beauty Destination</h1>
    <p>Makeup has been around for over a hundred thousand years, and beauty is only evolving. Meet Cosmotus, a
        powerful concoction of technology and beauty.<br> A portal which delivers the best of both the worlds.
    </p>
    <a href="" class="btn-link">Visit Us to Knew More</a>


</main>
<?php require_once "./footer.php" ?>

