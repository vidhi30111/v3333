<?php require_once "./header.php" ?>
<?php
include "conn.php";
?>
<?php
$limit=4;

if(isset($_GET['page'])){
    $page1=$_GET['page'];
}
else{
    $page1=1;
}
$offset=($page1-1) * $limit;
?>
<style>
    .box {
        position: relative;
    }

    .qq {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        opacity: 0;
        transition: opacity 0.4s ease-in-out;
        background: black;
        cursor: pointer;
    }

    .text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: #fff;
        font-family: verdana;
        text-align: left;
    }

    .box:hover .qq{
        opacity: 0.8;

    }

    .catimg {
        box-shadow: rgba(240, 240, 245, 0.4) 0px 7px 29px 0px;
        /* border-radius: 10px; */
        width:320px;
        height: 445px;

    }

    .btn1 {
        margin: 0;
        padding: 0;
        border: 0;
        background: none;

    }
    .pagination{
    
    align-items: center;
    justify-content: center;
    margin-top: -3px;
}
.pp{
    color: aliceblue;
    background: transparent;
    border: 1px solid #2a9191;
}

.pp:hover{
    color: aliceblue;
    background: #2a9191;
}

.aa{
    background-color: #216969;
}

</style>
<main>
    <div class="container">
        <div class="row">
            <?php
            $ss="SELECT * FROM beauty_advice";
            $sqll = "SELECT * FROM beauty_advice ORDER BY ba_id desc LIMIT {$offset},{$limit}";
            $r = mysqli_query($con, $sqll);
            $re = mysqli_num_rows($r);
            if ($re > 0) {
                while ($advice = mysqli_fetch_assoc($r)) {
            ?>
                    <div class="col-3">
                        <button type="submit" class="btn btn1" data-bs-toggle="modal" data-bs-target="#exampleModal" >
                            <div class="box">
                                <img src="../admin/upload/<?php echo ($advice['bimg']); ?>" class="catimg" alt="" srcset="">

                               <div class="qq"><h4 class="text"><?php echo ($advice['title']); ?></h4></div>
                                
                            </div>
                        </button>

                        <!-- Modal -->
                        <div class="modal fade"  id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class=" modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" >
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1><?php echo ($advice['title']); ?></h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <span><?php echo ($advice['des']); ?></span>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="button" class="btn btn-primary">Save changes</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            <?php

                }
            }

            ?>

        </div>
    </div> 

    <div class="pagination">
        <nav aria-label="Page navigation example" >
        <?php 
        $mm="adice";
        $res1=mysqli_query($con,$ss);
        if(mysqli_num_rows($res1)>0){
            $totalrec=mysqli_num_rows($res1);
            
            $totalpage=ceil($totalrec/$limit);
            echo '<ul class="pagination justify-content-center" >';
            if($page1>1){
                echo '<li class="page-item " > <a class="page-link pp" href="advice2.php?&page='.($page1-1).'">Previous</a> </li>';
            }
            for($i=1;$i<=$totalpage;$i++){
                $_SESSION['pagestate']='href="advice2.php?&page='.($page1).'"';
                if($i==$page1){
                    $act="aa";
                }else{
                    $act="";
                }
                echo '<li class="page-item  '.$act.'"><a class="page-link pp" href="advice2.php?&page='.$i.'">'.$i.'</a></li>';
            }
            if($totalpage>$page1){
                echo ' <li class="page-item"><a class="page-link pp" href="advice2.php?&page='.($page1+1).'">Next</a></li>';
            }
            
            echo '</ul>';

        }
    ?>    
        </nav>
    </div>
</main>
<?php require_once "./footer.php" ?>