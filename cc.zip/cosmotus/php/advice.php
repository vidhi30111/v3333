<?php require_once "./header.php" ?>
<style>
    .box {
        position: relative;
    }

    .middle {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        opacity: 0;
        transition: opacity 0.4s ease-in-out;
        background: black;
        cursor: pointer;
    }

    .text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: #fff;
        font-family: verdana;
        text-align: left;
    }

    .box:hover .middle {
        opacity: 0.8;

    }

    .catimg {
        box-shadow: rgba(240, 240, 245, 0.4) 0px 7px 29px 0px;
        /* border-radius: 10px; */
        width: 100%;
        height: 100%;
        
    }

    .btn {
        margin: 0;
        padding: 0;
        border: 0;
        background: none;

    }
    .tt1{
        background-color: #2a9191;
        color: #fff;
    }
    .tt2{
        background-color: gray;
        color: #fff;
    }
</style>
<main>
<div class="container">
        <!-- <form action="./product2.php" method="get"> -->
            <div class="row">
                <div class="col">
                <!-- <a href="product2.php?--=<?php //echo md5('skin'); ?>"> -->
                <button type="submit" name="skin">
               
                        <div class="box">
                            <img src="https://cdn.pixabay.com/photo/2018/03/01/16/45/skin-3191102_640.jpg" class="catimg" alt="" srcset="">
                            
                            <div class="middle">
                                <!-- <div class="text">
                                    h3>5 PERSONAL GROOMING TIPS EVERY WOMAN SHOULD KNOWE</h3>
                                    
                                </div> -->
                            </div>
                        <div class="tt1">How To Give Yourself A Face Massage For Glowing Skin</div>
                        </div>
                    <!-- </a >
                 -->
                 </button>
                 
                </div>
                <div class="col">
                <button type="submit" name="makuep">
                    <div class="box">
                        <img src="https://cdn.pixabay.com/photo/2017/05/28/09/44/woman-2350565_640.jpg" class="catimg" alt="" srcset="">

                        <div class="middle">
                            <!-- <div class="text">
                                <h3>MAKUP</h3>
                               
                            </div> -->
                        </div>
                        <div class="tt2">How To Oil Your Hair The Right Way</div>
                    </div>
                 </button>
                    
                </div>
                <div class="col">
                <button type="submit" name="hair">
                    <div class="box">
                        <img src="https://cdn.pixabay.com/photo/2017/06/01/16/08/woman-2363819_640.jpg" class="catimg" alt="" srcset="">

                        <div class="middle">
                            <!-- <div class="text">
                                <h3>HAIR CARE</h3>
                                
                            </div> -->
                        </div>
                        <div class="tt2">6 DUPES FOR DAILY MAKUEP</div>
                    </div>
                </button>
                </div>
                <div class="col">
                <!-- <button type="submit" >
                    <div class="box">
                        <img src="https://cdn.pixabay.com/photo/2022/07/14/03/52/woman-7320390_640.jpg" class="catimg" alt="" srcset="">

                        <div class="middle">
                             <div class="text">
                                <h3>BODY & BATH</h3>
                                
                            </div> -->
                        <!-- </div>
                        <div class="tt1">5 PERSONAL GROOMING TIPS EVERY WOMAN SHOULD KNOW</div>
                    </div>
                </button>
                </div>
            </div> --> 
            <!-- Button trigger modal -->
<button type="button" class="btn " data-bs-toggle="modal" data-bs-target="#exampleModal" name="body">
    <div class="box">
        <img src="https://cdn.pixabay.com/photo/2022/07/14/03/52/woman-7320390_640.jpg" class="catimg" alt="" srcset="">

        <div class="middle">
            <!-- <div class="text">
                <h3>BODY & BATH</h3>
                
            </div> -->
        </div>
        <div class="tt1">5 PERSONAL GROOMING TIPS EVERY WOMAN SHOULD KNOW</div>
    </div>
  </button>
  
  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          ...
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>
            </form>
    </div>
</main>
<?php require_once "./footer.php" ?>
