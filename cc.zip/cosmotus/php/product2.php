<?php
include "conn.php";
?>

<?php require_once "./header.php" ?>

<?php

 //print_r($_SESSION['cart']);
$limit=4;

if(isset($_GET['page'])){
    $page1=$_GET['page'];
}
else{
    $page1=1;
}
$offset=($page1-1) * $limit;

if(isset($_GET['skin']))  {
    $mm='skin';
    $s="SELECT * FROM products WHERE category='skincare' ";
    $sql = "SELECT * FROM products WHERE category='skincare' order by pid desc LIMIT {$offset},{$limit}";
}
elseif (isset($_GET['makuep'])) {
    $mm='makuep';

    $s="SELECT * FROM products WHERE category='makeup' order by pid desc";
    $sql = "SELECT * FROM products WHERE category='makeup' order by pid LIMIT 4";
}
elseif (isset($_GET['hair'])) {
    $mm='hair';

    $s="SELECT * FROM products WHERE category='hair' order by pid desc";
    $sql = "SELECT * FROM products WHERE category='hair' order by pid LIMIT 4";
}
elseif (isset($_GET['body'])) {
    $mm='body';

    $s="SELECT * FROM products WHERE category='body' order by pid desc";
    $sql = "SELECT * FROM products WHERE category='body' order by pid LIMIT 4";
}

else{
    header("location:./product.php");
}

?>
<style>
.avd:hover{
background: #2a9191 !important;
color: antiquewhite !important;
}

.pagination{
    
    align-items: center;
    justify-content: center;
    margin-top: -3px;
}
.pp{
    color: aliceblue;
    background: transparent;
    border: 1px solid #2a9191;
}

.pp:hover{
    color: aliceblue;
    background: #2a9191;
}

.aa{
    background-color: #216969;
}

</style>
<main>
    <div class="container">
        <div class="row">
            
            <?php
                $r = mysqli_query($con, $sql);
                $re = mysqli_num_rows($r);
                if ($re > 0) {
                    while ($product = mysqli_fetch_assoc($r)) {
            ?>
                        <div class="col-3" >
                        <form action="managecart.php" method="POST">
                            <div class="card" style="width: 287px !important;height: 450px !important; background:transparent; border:2px solid #fff; color:#fff; box-shadow:0px 0px 5px #bababa;">
                                <img src="../admin/upload/<?php echo ($product['proimg']); ?>" width="120px" height="200px" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo ($product['pname']); ?></h5>
                                    <h5 class="card-title"><?php echo 'Rs.'.($product['price']); ?></h5>
                                    <p style="width: 252px;height: 100px;" class="card-text"><?php echo ($product['des']); ?></p>
                                        <?php $pid=$product['pid']; ?>
                                    <button name="cart"  class="btn avd" style=" transition: 0.4s; background: transparent; border: 1px solid #2a9191; color:#fff; width:100%">Add to Cart</button>
                                </div>
                            </div>

                            <input type="hidden" name="hidid" value="<?php echo $product['pid']; ?>">
                            <input type="hidden" name="hidnm" value="<?php echo $product['pname']; ?>">
                            <input type="hidden" name="hidpr" value="<?php echo $product['price']; ?>">
                            <input type="hidden" name="hidimg" value="<?php echo $product['proimg']; ?>">
                            <input type="hidden" name="hidcat" value="<?php echo $product['category']; ?>">
                            <input type="hidden" name="hidqty" value="1">
                            </form>
                        </div>
            <?php
                    }
                }
                else{
                    echo"<h4 style='margin:15% 44%; color:#fff'>no product found</h4>";
                }
            ?>
            
        </div>
    </div>


    <?php 
       
        $res1=mysqli_query($con,$s);
        if(mysqli_num_rows($res1)>0){
            $tr=mysqli_num_rows($res1);
            $limit=4;
            $tp=ceil($tr/$limit);


        }
    ?>
    <div class="pagination">
        <nav aria-label="Page navigation example" >
        <?php 
        $res1=mysqli_query($con,$s);
        if(mysqli_num_rows($res1)>0){
            $totalrec=mysqli_num_rows($res1);
            
            $totalpage=ceil($totalrec/$limit);
            echo '<ul class="pagination justify-content-center" >';
            if($page1>1){
                echo '<li class="page-item " > <a class="page-link pp" href="product2.php?'.$mm.'&page='.($page1-1).'">Previous</a> </li>';
            }
            for($i=1;$i<=$totalpage;$i++){
                $_SESSION['pagestate']='href="product2.php?'.$mm.'&page='.($page1).'"';
                if($i==$page1){
                    $act="aa";
                }else{
                    $act="";
                }
                echo '<li class="page-item  '.$act.'"><a class="page-link pp" href="product2.php?'.$mm.'&page='.$i.'">'.$i.'</a></li>';
            }
            if($totalpage>$page1){
                echo ' <li class="page-item"><a class="page-link pp" href="product2.php?'.$mm.'&page='.($page1+1).'">Next</a></li>';
            }
            
            echo '</ul>';

        }
    ?>    
        </nav>
    </div>
</main>

<?php require_once "./footer.php" ?>