<?php
session_start();
include "conn.php";
$msg = "";
if (isset($_SESSION['usersession'])) {
    header("location:./home.php");
} else {
    if (isset($_POST['submit'])) {
        $usernm = $_POST['txtusernm'];
        $pas = $_POST['pass'];
        $pass = md5($pas);
        $sql = "select * from users where username='$usernm'";
        $res = mysqli_query($con, $sql);
        if (mysqli_num_rows($res) == 1) {
            $sql2 = "select * from users where username='$usernm' and password='$pass'";
            $res2 = mysqli_query($con, $sql2);
            if (mysqli_num_rows($res2) == 1) {
                $_SESSION['usersession'] = $usernm;
                header("location:./home.php");
            } else {
                $msg = "Password Incorrect Try Again";
            }
        } else {
            $msg = "User Not Found";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css    ">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;

            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-image: linear-gradient(rgba(4, 9, 30, 0.7), rgba(4, 9, 30, 0.7)), url('https://cdn.pixabay.com/photo/2023/06/30/09/09/composition-8097955_640.jpg');
            background-size: cover;
            background-position: center;
        }

        .wraper {
            width: 420px;
            background: transparent;
            color: #fff;
            border: 2px solid rgba(255, 255, 255, .2);
            backdrop-filter: blur(20px);
            box-shadow: 0 0 10px rgba(0, 0, 0, .2);
            border-radius: 10px;
            padding: 30px 40px;
        }

        .wraper h1 {
            font-size: 36px;
            text-align: center;

        }

        .wraper .input-box {
            width: 100%;
            height: 50%;
            position: relative;

            margin: 30px 0;

        }

        .input-box input {
            width: 100%;
            height: 100%;
            background: transparent;
            border: none;
            outline: none;
            border: 2px solid rgba(255, 255, 255, .2);
            border-radius: 40px;
            font-size: 16px;
            color: #fff;
            padding: 20px 45px 20px 45px;
        }

        .input-box input::placeholder {
            color: #fff;

        }

        .input-box svg {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
        }

        

        .wraper .btn {
            width: 100%;
            height: 45px;
            background: #2a9191;
            border: none;
            outline: none;
            border-radius: 40px;
            box-shadow: 0 0 10px rgba(0, 0, 0, .1);
            cursor: pointer;
            font-size: 16px;
            color: #fff;
            font-weight: 600;
        }

        .wraper .btn:hover {
            border: 2px solid rgba(255, 255, 255, .2);
            background: transparent;
            color: #fff;
            transition: 1s;
        }

        .wraper .register-link {
            font-size: 14.5px;
            text-align: center;
            margin: 20px 0 15px;


        }

        .register-link p a {
            color: #fff;
            text-decoration: none;
            font-weight: 600;

        }

        .register-link p a:hover {
            text-decoration: underline;
        }

        .msg {
            color: #2a9191;
            font-weight: 700;
            text-align: center;
            margin-top: 25px;
            margin-bottom: -6px;
            text-decoration: underline;

        }
        .wraper .remember-forgot {
            display: flex;
            justify-content: space-between;
            font-size: 14.5px;
            margin: -15px 0 15px;
        }

        .remember-forgot label input {
            accent-color: #fff;
            margin-right: 3px;
        }

        .remember-forgot a {
            color: #fff;
            text-decoration: none;
        }

        .remember-forgot a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="wraper">
        <form action="<?php echo ($_SERVER['PHP_SELF']) ?>" method="post">
            <h1>Login</h1>
            <p class="msg"><?php echo $msg; ?></p>
            <div class="input-box">
                <input type="text" placeholder="Username" name="txtusernm" required>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                    <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
                </svg>
            </div>
            <div class="input-box">
                <input type="password" placeholder="Password" name="pass" required><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-lock-fill" viewBox="0 0 16 16">
                    <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z" />
                </svg>
            </div>
            <div class="remember-forgot">
                <label for=""><input type="checkbox">Remember me</label>
                <a href="#">Forgot Password</a>
            </div>
            <button type="submit" name="submit" class="btn">Sign In</button>
            <div class="register-link">
                <p>Don't have an account? <a href="signup.php">Sign Up</a></p>
            </div>
        </form>
    </div>
</body>

</html>