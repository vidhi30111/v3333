<?php
session_start();
if(isset($_SESSION['usersession'])){
    session_destroy();
    header('location:./signin.php');
}
?>