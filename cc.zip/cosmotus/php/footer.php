<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
</section>
    </body>
<footer style="position: absolute;
    bottom: 2%;
    left: 44%;
    color: #ffffffa1;">
        cecopyright@ registered
    </footer>

   
    
<script src="../js/bootstrap.bundle.min.js"></script> 


</html>