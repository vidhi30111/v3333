<?php require_once "./header.php" ?>
<style>

</style>
<main>

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Launch demo modal
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered "  >
    <div class="modal-content" >
      <div class="modal-header">
        <h1 class="modal-title " id="exampleModalLabel">Face Wash</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <img src="https://cdn.pixabay.com/photo/2021/02/26/11/51/cosmetics-6051633_640.jpg" style="border: 2px solid white;" width="100%" height="200px" alt="">
   

<h4>Category : Skin Care</h4>
<select name="qty"  id="">
    <option value="1">Qty</option>
    <option value="1">2</option>
    <option value="1">3</option>
</select>
<h3>500 Rs.</h3>



<h5 class="des">Specification:</h5>

<p >
    Face serums help shrink pores and increase cell turnover further leading to the minimisation of large pores.
</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Buy Now</button>
        <button type="button" class="btn " style="background: #2a9191; color:aliceblue">Add to Cart</button>
      </div>
    </div>
  </div>
</div>
</main>


<?php require_once "./footer.php" ?>