<?php
session_start();
if(isset($_SESSION['usersession'])){
if(isset($_POST['cart'])){
    if(isset($_SESSION['cart'])){
        $pidd=array_column($_SESSION['cart'],'id');
        //1,2
        if(in_array($_POST['hidid'],$pidd)){
            echo '<script> alert("Product already Added"); window.location.'.$_SESSION['pagestate'].'</script>';
        }else{
                $c=count($_SESSION['cart']);
                $_SESSION['cart'][$c]=array('id'=>$_POST['hidid'],'name'=>$_POST['hidnm'],'price'=>$_POST['hidpr'],'img'=>$_POST['hidimg'],'qty'=>$_POST['hidqty'],'cat'=>$_POST['hidcat']);
                echo '<script> alert("Product Added"); window.location.'.$_SESSION['pagestate'].'</script>';        
            }
    }else{
        $_SESSION['cart'][0]=array('id'=>$_POST['hidid'],'name'=>$_POST['hidnm'],'price'=>$_POST['hidpr'],'img'=>$_POST['hidimg'],'qty'=>$_POST['hidqty'],'cat'=>$_POST['hidcat']);
        echo '<script> alert("Product Added"); window.location.'.$_SESSION['pagestate'].'</script>';
    }
}
}
else{
    echo '<script> alert("You have to Login First!"); window.location.href="./signin.php"</script>';
}

?>