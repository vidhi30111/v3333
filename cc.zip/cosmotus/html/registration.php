<?php
include "conn.php";

if (isset($_POST['submit'])) {

  $usernm = $_POST['txtusername'];
  $email = $_POST['txtemail'];
  $pas = $_POST['pass'];
  $cpas = $_POST['cpass'];
  if ($pas == $cpas) {
    $usercheck = "select * from users where username='$usernm'";
    $userc = mysqli_query($con, $usercheck);
    if (mysqli_num_rows($userc) == 0) {
      $emailcheck = "select * from users where email='$email'";
      $emailc = mysqli_query($con, $emailcheck);
      if (mysqli_num_rows($emailc) == 0) {
        $pa = md5($pas);
        $query = "INSERT INTO users ( username, email, password) VALUES ( '$usernm', '$email', '$pa')";
        $res = mysqli_query($con, $query);
        if ($res) {
          echo "inserted";
        } else {
          echo "not inserted";
        }
      } else {
        echo " email registered";
      }
    } else {
      echo ("UserName registerd");
    }
  } else {
    echo ("password not match");
  }
}

?>









<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SignUp</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<style>
  .fffff:hover {
    color: transparent;
    -webkit-text-stroke: 2px black;

  }

  .ddd::placeholder {
    color: #fff;

  }

  .bu {
    background-color: rgba(231, 44, 72, 0.6);
    color: antiquewhite;
  }

  .bu:hover {
    background-color: rgba(231, 44, 72);
    color: antiquewhite;
  }

  a {
    margin-left: 2px;
    font-weight: bolder;
    text-decoration: none;
    color: rgba(231, 44, 72, 0.6);
  }

  a:hover {
    color: rgba(231, 44, 72);
    text-decoration: underline;
  }
</style>

<body style="background:url(https://cdn.pixabay.com/photo/2023/06/30/09/09/composition-8097955_640.jpg);background-size: cover;
    background-position: center;">
  <section class="vh-100">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-lg-12 col-xl-11">
          <div class="card text-black" style="background:transparent;color: #fff;border: 2px solid rgba(255, 255, 255, .2);backdrop-filter: blur(20px);box-shadow: 0 0 10px rgba(0, 0, 0, .2);border-radius: 10px;">
            <div class="card-body p-md-5">
              <div class="row justify-content-center">
                <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">

                  <p class="fffff text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4" style="color:#fff;">Sign up</p>

                  <form class="mx-1 mx-md-4 " action="registration.php" method="post">
                    <div class="row">
                      <div class="col">
                        <div class="form-outline flex-fill mb-0">
                          <input type="text" name="txtusername" id="form3Example1c" style="width: 100%;height: 100%;background: transparent;border: none;outline: none;border: 2px solid rgba(255, 255, 255, .2);border-radius: 40px;font-size: 16px;color: #fff;padding: 20px 45px 20px 45px;" class="form-control ddd mb-4" placeholder="User Name" required />

                        </div>
                      </div>
                      <div class="col">
                        <div class="form-outline flex-fill mb-0">
                          <input type="email" name="txtemail" id="form3Example1c" style="width: 100%;height: 100%;background: transparent;border: none;outline: none;border: 2px solid rgba(255, 255, 255, .2);border-radius: 40px;font-size: 16px;color: #fff;padding: 20px 45px 20px 45px;" class="form-control ddd mb-4" placeholder="email" required />

                        </div>
                      </div>
                    </div>
                    <div class="row">

                      <div class="form-outline flex-fill mb-0">
                        <input type="text" name="txtadd" id="form3Example1c" style=" margin-top:-13px;width: 100%;height: 100%;background: transparent;border: none;outline: none;border: 2px solid rgba(255, 255, 255, .2);border-radius: 40px;font-size: 16px;color: #fff;padding: 20px 45px 20px 45px;" class="form-control ddd mb-4" placeholder="Address" />

                      </div>


                    </div>
                    <div class="row">
                      <div class="col">
                        <div class="form-outline flex-fill mb-0">
                          <input type="password" name="pass" id="form3Example1c" style="width: 100%;height: 100%;background: transparent;border: none;outline: none;border: 2px solid rgba(255, 255, 255, .2);border-radius: 40px;font-size: 16px;color: #fff;padding: 20px 45px 20px 45px;" class="form-control ddd mb-4" placeholder="Password" required />

                        </div>
                      </div>
                      <div class="col">
                        <div class="form-outline flex-fill mb-0">
                          <input type="password" name="cpass" id="form3Example1c" style="width: 100%;height: 100%; background: transparent;border: none;outline: none;border: 2px solid rgba(255, 255, 255, .2);border-radius: 40px;font-size: 16px;color: #fff;padding: 20px 45px 20px 45px;" class="form-control ddd mb-4" placeholder="Confirm Password" required />

                        </div>
                      </div>
                    </div>
                    <!-- <div class="row">
                        <div class="col">
                            <div class="form-outline flex-fill mb-0">
                                <input type="text" id="form3Example1c" style="width: 100%;height: 100%;background: transparent;border: none;outline: none;border: 2px solid rgba(255, 255, 255, .2);border-radius: 40px;font-size: 16px;color: #fff;padding: 20px 45px 20px 45px;"  class="form-control ddd mb-4" placeholder="Your Name"  />
                                
                              </div>
                        </div>
                        <div class="col">
                            <div class="form-outline flex-fill mb-0">
                                <input type="text" id="form3Example1c" style="width: 100%;height: 100%;background: transparent;border: none;outline: none;border: 2px solid rgba(255, 255, 255, .2);border-radius: 40px;font-size: 16px;color: #fff;padding: 20px 45px 20px 45px;"  class="form-control ddd mb-4" placeholder="Your Name" required />
                                
                              </div>
                        </div>
                    </div> -->







                    <div class="mt-4">
                      <button type="submit" name="submit" style="width: 100%;" class="btn bu btn-lg">Register</button>
                    </div>
                    <h5 class="mt-4 ms-2" style="color: bisque;"> Alredy have an account? <a href="signin.php">Sign in</a></h5>
                  </form>

                </div>
                <div class="col-md-10  col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2 ">

                  <img style="border-radius: 20px; height: 400px; width: 300px; margin-left: 125px ; margin-top: 30px;" src="https://cdn.pixabay.com/photo/2023/06/30/09/09/composition-8097955_640.jpg" class="img-fluid" alt="Sample image">

                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="../js/bootstrap.bundle.min.js"></script>
</body>

</html>