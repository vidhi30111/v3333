<?php require_once "./header.php" ?>
<style>
    .box {
        width: 900px;
        /* height: 500px; */
        background: transparent;
        color: #fff;
        border: 3px solid rgba(255, 255, 255, .2);
        backdrop-filter: blur(20px);
        box-shadow: 0 0 10px rgba(0, 0, 0, .2);
        margin: 1rem 0;
        padding: 2rem 0;
        display: grid;
        margin-left: 20%;
        grid-template-columns: repeat(2, 1fr);
        border-radius: 10px;
        column-gap: 10px;

    }

    img {
        width: 100%;
        height: 360px;
        border-radius: 10px;

    }

    .left-div {
        padding: 0 20px;
        align-items: center;
    }

    .right-div {
        padding: 20px;
    }

    .cart {
        width: 40%;
        height: 45px;
        background: #2a9191;
        border: none;
        outline: none;
        border-radius: 40px;
        box-shadow: 0 0 10px rgba(0, 0, 0, .1);
        cursor: pointer;
        font-size: 16px;
        color: #fff;

    }

    .buy {
        width: 40%;
        height: 45px;
        background: grey;
        border: none;
        outline: none;
        border-radius: 40px;
        box-shadow: 0 0 10px rgba(0, 0, 0, .1);
        cursor: pointer;
        font-size: 16px;
        color: #fff;
    }

    .ho:hover{
        border: 2px solid rgba(255, 255, 255, .2);
            background: transparent;
            color: #fff;
            transition: 1s;
    }

    .des{
        margin-top: 10px;
    }

    select{
        margin-top: 10px;
        margin-bottom: 10px;
        width: 20%;
        background: transparent;
        color: #fff;
        border-radius: 5px;
        font-weight: 600;
    
    }

    option{
        color: black;
        font-weight: 600;
        background-color: rgb(167, 167, 167) ;
    }

   
</style>
<main>
    <div class="box">

        <div class="left-div">
            <img src="https://cdn.pixabay.com/photo/2021/02/26/11/51/cosmetics-6051633_640.jpg" alt="">
        </div>
        <div class="right-div">
            <h1 class="pname">Face Wash</h1>

            <h3>Category : Skin Care</h3>
            <select name="qty"  id="">
                <option value="1">Qty</option>
                <option value="1">2</option>
                <option value="1">3</option>
            </select>
            <h3>500 Rs.</h3>
            
            <button type="submit" class="cart ho">Add to Cart</button>
            <button type="submit" class="buy ho">Buy Now</button>
            
            <h5 class="des">Specification:</h5>
           
            <p >
                Face serums help shrink pores and increase cell turnover further leading to the minimisation of large pores.
            </p>

        </div>

    </div>
</main>
<?php require_once "./footer.php" ?>