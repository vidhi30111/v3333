<?php 
include "../php/conn.php";
?>
<?php
if(isset($_POST['prosub'])){
    $n=$_POST['pn'];
    $c=$_POST['pc'];
    $p=$_POST['pr'];
    $q=$_POST['pq'];
    $d=$_POST['de'];

    $filenm=$_FILES['file']['name'];
    $basenm=substr($filenm,0,strripos($filenm,'.'));
    $ext=substr($filenm,strripos($filenm,'.'));
    $tmpnm=$_FILES['file']['tmp_name'];
    $alowtyp=array(".jpg",".png");
    if(in_array($ext,$alowtyp)){
        $newfilenm=md5($basenm).rand(10,1000).time().$ext;
        if(file_exists("upload/".$newfilenm)){
            echo "file existst";
        }else{
            move_uploaded_file($tmpnm,"upload/".$newfilenm);
            if($n!="" && $c!="" && $p!="" &&$q!="" && $d!=""  ){
                $ip="INSERT INTO products ( pname, category, price, qty, des,proimg) VALUES ('$n','$c','$p','$q','$d','$newfilenm')";
                $r=mysqli_query($con,$ip);
                if($r){
                    echo "INSERTED";
                }else{
                    echo "INSERt FAILED";
                }
            }else{
                echo "fiels is empty";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="file1.php" method="post" enctype="multipart/form-data">
    <input type="file" name="file"><br>
        <input type="text" name="pn" placeholder="PRODUCT NAME"><br>
        <input type="text" name="pc" placeholder="PRODUCT CATEGORY"><br>
        <input type="text" name="pr" placeholder="PRODUCT price"><br>
        <input type="text" name="pq" placeholder="PRODUCT qty"><br>
        <textarea name="de" id="" cols="30" placeholder="PRODUCT DES" rows="10"></textarea><br>

        <button type="submit" name="prosub">submit</button>
</body>

</html>