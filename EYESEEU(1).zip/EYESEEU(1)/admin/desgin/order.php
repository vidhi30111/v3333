<div class="container mt-5">
    <h6><?php?></h6>
    <div class="row">
        <table class="table text-center mt-1 table-bordered">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Password</th>
                </tr>
            </thead>
            <?php 
            $query = "";
            ?>
        </table>
    </div>
</div>