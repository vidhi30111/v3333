<?php require_once "./header.php" ?>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        outline: none;
    }

    .col {
        position: relative;
        box-sizing: border-box;
    }


    .container {
        width: 100%;
        /* min-height:100vh; */
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 50px 8%;
        position: absolute;
        top: 5%;
        right: 10%;
        height: 100%;
        width: 100%;
    }

    /* .sss{
        margin: 0;
        padding: 0;
        border: 0;
        background: none;
        
    } */
    /* .text{
        position: absolute;
        top: 50%;
        left:50%;
        transform: translate(-25%,-25%);
        text-align: center;
        color: blanchedalmond;

    } */
    .image {
        width: 500px;
        position: relative;

    }

    .img {
        width: 100%;
        display: block;
        margin: auto;

    }

    .content {
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        position: absolute;
        background: rgba(0, 0, 0, 0.6);
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        opacity: 0;
        transition: 0.6s;

    }

    .content:hover {
        opacity: 1;
    }

    .content h3 {
        font-size: 55px;
        color: rgb(165, 148, 148);
        margin-bottom: 15px;

    }

    .content>* {
        transform: translateY(25px);
        transition: transform 0.6s;
    }

    .content:hover>* {
        transform: translateY(0px);

    }
</style>
<main>
    <div class="container">
        <form action="./product2.php" method="get">
            <div class="row">
                <div class="col">
                    <!-- <a href="./product2.php?specs=specs" class="sss"> -->
                        <button type="submit" name="specs" class="sss">
                        <div class="box">
                            <img src="https://cdn.pixabay.com/photo/2013/07/07/05/43/glasses-143762_640.jpg" alt=""
                                height="300px" width="300px">
                            <div class="content">
                                <h3>specs</h3>

                            </div>
                        </div>
                    <!-- </a> -->
                    </button>
                </div>
                <div class="col">
                    <button type="submit" name="lens" class="sss">
                        <div class="box">
                            <img src="https://cdn.pixabay.com/photo/2013/07/07/05/43/glasses-143762_640.jpg" alt=""
                                height="300px" width="300px">
                            <div class="content">
                                <h3>Lens</h3>
                            </div>
                        </div>
                    </button>
                </div>
                <div class="col">
                    <button type="submit" name="goggles" class="sss">
                        <div class="box">
                            <img src="https://cdn.pixabay.com/photo/2013/07/07/05/43/glasses-143762_640.jpg" alt=""
                                height="300px" width="300px">
                            <div class="content">
                                <h3>Goggles</h3>
                            </div>
                        </div>
                    </button>
                </div>
            </div>
        </form>
    </div>


</main>

<?php require_once "./footer.php" ?>