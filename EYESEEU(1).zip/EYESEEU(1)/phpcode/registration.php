<?php
include "./confi.php";
if(isset($_POST['reg'])){
  $u=$_POST['txtusername'];
  $e=$_POST['txtemail'];
  $p=$_POST['pass'];
  $cp=$_POST['cpass'];
  if($p==$cp){
    $usercheck="select * from users where username='$u'";
    $userc=mysqli_query($con,$usercheck);
   if( mysqli_num_rows($userc)==0){
    $emailcheck="select * from users where email='$e'";
    $emailc=mysqli_query($con,$emailcheck);
   if( mysqli_num_rows($emailc)==0){
      $pa=md5($p);
    $res="INSERT INTO users(email, username, password) VALUES ('$e','$u','$pa') ";
    $result=mysqli_query($con,$res);
    if($result){
      header("location:./login.php");
    }
    else{
      echo "Value Not Inserted";
    }
   }
   }
  }
  else{
    echo ("Password do not match");
  }
}
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script> 
</head>
<style>
  .fffff:hover {
    color: transparent;
    -webkit-text-stroke: 2px black;
  }

  .ddd::placeholder {
    color: grey;
    padding: 10px;
  }

  .bu {
    background-color: rgba(231, 44, 72, 0.6);
    color: antiquewhite;
  }

  .bu:hover {
    background-color: rgb(155, 32, 51);
    color: antiquewhite;
  }

  a {
    margin-left: 2px;
    font-weight: bolder;
    text-decoration: none;
    color: rgba(231, 44, 72, 0.6);
  }

  a:hover {
    color: rgb(245, 110, 130);
    text-decoration: underline;
  }
</style>

<body>
  <section class="vh-100" style="background:linear-gradient(45deg, #4d1eaa, #d14c59, #d67534);">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-lg-12 col-xl-11">
          <div class="card text-black"
            style="border-radius: 25px;border: none;background:linear-gradient(0deg, #e7b1e7 0%, #e9d2fd 100%);">
            <div class="card-body p-md-5">
              <div class="row justify-content-center">
                <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">

                  <p class="fffff text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Sign up</p>

                  <form class="mx-1 mx-md-4 " method="post" action="<?php $_SERVER['PHP_SELF']?>">
                    <div class="row">
                      <div class="col">
                        <div class="form-outline flex-fill mb-0">
                          <input type="text" id="form3Example1c" class="form-control ddd mb-4" name="txtusername" placeholder="Username"
                            required />

                        </div>
                      </div>

                    </div>
                    <div class="row">

                      <div class="form-outline flex-fill mb-0">
                        <input type="email" id="form3Example1c" class="form-control ddd mb-4" name="txtemail" placeholder="Email"
                          required />

                      </div>


                    </div>
                    <div class="row">
                      <div class="col">
                        <div class="form-outline flex-fill mb-0">
                          <input type="password" id="form3Example1c" class="form-control ddd mb-4" name="pass" placeholder="Password"
                            required />

                        </div>
                      </div>
                      
                    </div>
                    <div class="row">
                      <div class="col">
                        <div class="form-outline flex-fill mb-0">
                          <input type="password" id="form3Example1c" class="form-control ddd mb-4" name="cpass" placeholder="Confirm Password" 
                            required />

                        </div>
                      </div>

                    </div>
                    <div class="mt-4">
                      <button type="submit" name="reg" style="width: 100%;" class="btn bu btn-lg">Register</button>
                    </div>
                    <h5 class="mt-4 ms-2" style="color: rgb(114, 26, 41);"> Click Here For Login: <a
                        href="login.php">Login</a></h5>
                  </form>

                </div>
                <div class="col-md-10  col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2 ">

                  <img style="border-radius: 20px; height: 400px; width: 300px; margin-left: 125px ; margin-top: 30px;"
                    src="https://cdn.pixabay.com/photo/2020/10/14/18/35/sign-post-5655110_1280.png" class="img-fluid"
                    alt="Sample image">

                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

</body>

</html>