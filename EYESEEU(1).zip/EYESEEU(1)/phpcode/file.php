<?php
if(isset($_POST['submit'])){
    $filenm=$_FILES['file']['name'];
    $basenm=substr($filenm,0,strripos($filenm,'.'));
    $ext=substr($filenm,strripos($filenm,'.'));
    $tmpnm=$_FILES['file']['tmp_name'];
    $alowtyp=array(".jpg",".png");
    if(in_array($ext,$alowtyp)){
        $newfilenm=md5($basenm).rand(10,1000).time().$ext;
        if(file_exists("upload/".$newfilenm)){
            echo "file existst";
        }else{
            move_uploaded_file($tmpnm,"upload/".$newfilenm);
            echo "succesfull";
        }
    }
    else{
        echo"aloow file are jpg and png";
    }
}

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="file.php" method="post" enctype="multipart/form-data">
        <input type="file" name="file">
        <button type="submit" name="submit">submit</button>
    </form>
</body>
</html>