<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <nav>
        <header>
            <div class="banner">
                <div class="navbar">
                    <a href="./home.php"><img src="https://cdn.pixabay.com/photo/2020/04/03/07/26/eye-4997724_640.png"
                            class="logo" height="100px" width="100px"></a>
                    <ul>
                        <li><a href="./home.php">Home</a></li>
                        <li><a href="./product.php">Products</a></li>
                        <li><a href="./about.php">About Us</a></li>
                        <li><a href="./cart.php">Add To Cart <sup>3</sup></a></li>

                        <?php 
                        if(isset($_SESSION['usersession']))
                        {
                          echo '<li><a href="./logout.php">'.$_SESSION['usersession'].'</a></li>';
                        }else{
                        echo '<li><a href="./login.php">SIGN IN</a></li>';
                        } ?>
                    </ul>
                </div>
            </div>
        </header>
    </nav>
