<?php
$con=mysqli_connect("localhost","root","","eyeseeu(1)") or die("cant connect to databse")
?>