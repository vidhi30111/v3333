<?php require_once "./header.php" ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./style.css">
</head>


<main>
    <div class="content">
        <h1>VISUALIZE YOUR WORLD</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam, corporis labore.
            distinctio <br>voluptates quasi. Corrupti odit esse est voluptatem aspernatur.</p>
        <div>
            <button type="button"><span></span>WATCH MORE</button>
            <button type="button"><span></span>CLICK HERE</button>
        </div>
    </div>
    
</main>

<?php require_once "./footer.php" ?>
</html>