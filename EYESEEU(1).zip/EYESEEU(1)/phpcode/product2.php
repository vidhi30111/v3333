<?php 
include "./confi.php";
?>
<?php require_once "./header.php" ?>
<style>
    .container {
        /* width: 100%;
        /* min-height:95vh;  */
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 50px 8%;
        position: absolute;
        top: 2%;
        left: 4%;
        height: 95%;
        /* width: 500px; */
        /* margin-bottom: 20px; */
        *
    }

    .lii {
        border: 0.5px solid antiquewhite;
        margin: 0 2px;
        padding: 5px;

    }

    .lii a {
        text-decoration: none;
        color: aqua;
    }

    .activee {
        background: white;

    }
    

</style>
<main>
    <div class="container">
        <?php 
        // print_r($_SESSION['cart']);
   $limit = 4;
//   $page=$_POST['page'];
   if(isset($_GET['page'])){
    $page=$_GET['page'];
   }else{
    $page=1;
   }
   $offset= ($page - 1) * $limit;

   if(isset($_GET['specs'])){
    $pg='specs';
    $sql1= "SELECT * FROM products WHERE category='specs'";
    $sql=" SELECT * FROM products WHERE category='specs' LIMIT $offset,$limit";
   }
   elseif(isset($_GET['lens'])){
    $pg='lens';
    $sql1= "SELECT * FROM products WHERE category='lens'";
    $sql=" SELECT * FROM products WHERE category='lens' LIMIT $offset,$limit";
   }
   elseif(isset($_GET['goggles'])){
    $pg='goggles';
    $sql1= "SELECT * FROM products WHERE category='goggles'";
    $sql=" SELECT * FROM products WHERE category='goggles' LIMIT $offset,$limit";
   }
   else{
    header("loaction:./product.php");
   }
   ?>
        <main>
            <div class="container">
                <div class="row">
                    <?php 
          
           $r=mysqli_query($con,$sql);
           $re=mysqli_num_rows($r);
           if($re>0){
               while($product=mysqli_fetch_assoc($r)){
                   ?>


                    <div class="col-3">
                        <form action="managecart.php" method="post">
                            <div class="card m-2 cb1 text-center" style="width: 250px ; height: 400px;">
                                <img src="../admin/upload/<?php echo ($product['proimages']); ?>" class="card-img-top"
                                    alt="..." height="150px" width="200px">
                                <div class="card-body">
                                    <h5 class="card-title mb-4">
                                        <?php  echo ($product['pname']); ?>
                                    </h5>
                                    <p class="card-text">
                                        <?php  echo ($product['des']); ?>
                                    </p>
                                    <select class="power">
                                    
                                        <option value="" selected="selected" hidden="" disabled="">Select Power
                                        </option>
                                        <option value="0.00">0.00</option>
                                        <option value="0.50">0.50</option>
                                        <option value="0.75">0.75</option>
                                        <option value="1.00">1.00</option>
                                        <option value="1.25">1.25</option>
                                        <option value="1.50">1.50</option>
                                        <option value="1.75">1.75</option>
                                        <option value="2.00">2.00</option>
                                        <option value="2.25">2.25</option>
                                        <option value="2.50">2.50</option>
                                        <option value="2.75">2.75</option>
                                        <option value="3.00">3.00</option>
                                        <option value="3.25">3.25</option>
                                        <option value="3.50">3.50</option>
                                        <option value="3.75">3.75</option>
                                        <option value="4.00">4.00</option>
                                        <option value="4.25">4.25</option>
                                        <option value="4.50">4.50</option>
                                        <option value="4.75">4.75</option>
                                        <option value="5.00">5.00</option>
                                        <option value="5.25">5.25</option>
                                        <option value="5.50">5.50</option>
                                        <option value="5.75">5.75</option>
                                        <option value="6.00">6.00</option>
                                        <option value="6.50">6.50</option>
                                        <option value="7.00">7.00</option>
                                        <option value="7.50">7.50</option>
                                        <option value="8.00">8.00</option>
                                        <?php  echo ($product['power']); ?>
                                    </select>
                                    <p class="card-text">
                                        <?php  echo ($product['price']); ?>
                                    </p>
                                    <!-- <a href="#" class="btn btn-primary">Add To Cart</a> -->
                                    <!-- <a href="#" class="btn btn-primary">Back</a> -->
                                    <button name="cart" class="text-center text-dark ">
                                        Add To Cart
                                    </button>
                                </div>
                            </div>
                            <input type="hidden" name="hid" value="<?php  echo ($product['pid']); ?>">
                            <input type="hidden" name="hname" value="<?php  echo ($product['pname']); ?>">
                            <input type="hidden" name="hdes" value="<?php  echo ($product['des']); ?>">
                            <input type="hidden" name="hqty" value="1">
                            <input type="hidden" name="hprice" value="<?php  echo ($product['price']); ?>">
                            <input type="hidden" name="himages" value="<?php  echo ($product['proimages']); ?>">
                            <input type="hidden" name="hpower" value="<?php  echo ($product['power']); ?>">


                        </form>
                    </div>
                    <?php
               }
           }
           else{
               echo"This Category is Empty";
           }
           ?>
                </div>
                <nav aria-label="..." style="position: absolute; bottom: 2%;">
                    <?php
       $res1 = mysqli_query($con,$sql1);
       if(mysqli_num_rows($res1) > 0){
        $total_records = mysqli_num_rows($res1);
        $total_page = ceil($total_records/ $limit);
        echo '<ul class="pagination admin-pagination">';
        if($page > 1){
            echo '<li class="lii"><a href="product2.php?'.$pg.'&page='.($page - 1).'">Prev</a></li>';
        }
        for($i=1 ;$i <= $total_page; $i++){
            $_SESSION['pagestate']='href="product2.php?'.$pg.'&page='.($page).'"';
            if($i== $page){
                $active = "activee";
            }
            else{
                $active = "";
            }
            echo ' <li class="lii '.$active.'"><a href="product2.php?'.$pg.'&page='.$i.'">'.$i.'</a></li>';

        }
        if($total_page > $page){
            echo '<li class="lii"><a href="product2.php?'.$pg.'&page='.($page + 1).'">Next</a></li>';
        }
        echo '</ul>';
       }
   ?>
                </nav>
                <!-- <div class="row">
                        
                        
                            <li class="page-item active" aria-current="page">
                            <span class="page-link">1</span>
                            </li>

                        </div>-->
            </div>
        </main>

        <?php require_once "./footer.php" ?>