<style>
  .container {
        width: 100%;
        /* min-height:100vh; */
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 50px 8%;
        position: absolute;
        top: 5%;
        right: 10%;
        height: 100%;
        width: 100%;
    }
</style>
<?php include('./header.php') ;?>
<div class="container">
<main>
  
<table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Description</th>
      <th scope="col">Price</th>
      <th scope="col">Power</th>
    </tr>
  </thead>
  <tbody >
    <?php foreach($_SESSION['cart'] as $k=>$v){ 
    echo '<tr>
    <th scope="row">'.$v['id'].'</th>
    <td>'.$v['name'].'</td>
    <td>'.$v['des'].'</td>
    <td>'.$v['price'].'</td>
    <td>'.$v['pow'].'</td>
  </tr>';
  // echo '<pre>'; print_r($v['pow']); echo '</pre>';
  } ?>
  </tbody>
</table>

</main>
</div>

<?php include('./footer.php') ;?>

